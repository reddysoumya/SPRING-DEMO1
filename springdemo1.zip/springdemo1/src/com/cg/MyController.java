package com.cg;

import java.sql.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class MyController {
	
	@RequestMapping("/hello")
public ModelAndView mtdName(){
	String today=new Date(0).toString();
	return new ModelAndView("hello","today",today);
	
}
	@RequestMapping("/hello1")
	public ModelAndView mtd(){
		String tomorrow=new Date(1).toString();
		return new ModelAndView("login");
	}
}
