package com.cg;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class LoginController {
	@RequestMapping("/login")
public ModelAndView m1(){
	String username="avinash";
	return new ModelAndView("success","username",username);
}
	@RequestMapping(value="/showpage",method=RequestMethod.GET)
	public String m2(Model model){
		String username="avinash";
		model.addAttribute("username",username);
		return "success";
	}
	@RequestMapping("/servlet1")
	public String test(@RequestParam("username")String n,@RequestParam("password")String pass,Model m){
		m.addAttribute("username",n);
		return "success";
	}
}
